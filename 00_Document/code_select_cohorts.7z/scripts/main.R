rm(list=ls())

source("functions/euclideanFactorCoding.R")
source("functions/convertDataYear2Ordinal.R")
source("functions/convertDate2DrugAvailability.R")
source("functions/convertLesionNumbers.R")
source("functions/splitData.R")
source("functions/RemoveRecordsShortInterval.R")
source("functions/convertPreblBinaries.R")
source("functions/simpleImpute.R")




myDataFrame <- read.csv("../../../data/2015-08-21/MS_decsupp_analset.csv", 
                        header=TRUE, sep=",")

# convert the index date to a set of binaries indicating after/before drug availabilities

dateConvertedDataFrame <- convertDate2DrugAvailability(myDataFrame)


vars2Drop <- c("idx_rx", 
               "rx_fing_1", "rx_ga_1", "rx_nat_1", "rx_ext_1", "rx_avo_1",
               "rx_reb_1", "rx_bet_1", "rx_tecf_1", "rx_teri_1")

# remove the variables not to be used

varRemovedDataFrame <- dateConvertedDataFrame[, !(names(dateConvertedDataFrame) %in% vars2Drop)]




# remove records whose baseline_edss_score are missing

records2Drop <- which(varRemovedDataFrame$baseline_edss_score %in% c(NA))

recordRemovedDataFrame <- varRemovedDataFrame[-records2Drop,]

# define all the factor variables - turns out to be all defined


# # convert the date and years into numbers
# 
# # recordRemovedDataFrame$idx_dt <- convertDate2Ordinal(recordRemovedDataFrame$idx_dt)
# recordRemovedDataFrame$idxyr <- convertYear2Ordinal(recordRemovedDataFrame$idxyr)

# remove idxyr

recordRemovedDataFrame$idxyr <- NULL

# convert "" in  brith_region to NA

recordRemovedDataFrame$birth_region[recordRemovedDataFrame$birth_region == ""] <-
  NA
recordRemovedDataFrame$birth_region <- factor(recordRemovedDataFrame$birth_region)

# convert last_cranial_num and last_spinal_num to 3 level categories, including na

recordRemovedDataFrame$last_spinal_num <- 
  convertSpinalNumbers(recordRemovedDataFrame$last_spinal_num)

recordRemovedDataFrame$last_cranial_num <- 
  convertCranialNumbers(recordRemovedDataFrame$last_cranial_num)

# convert relapse_fu_any to binary

recordRemovedDataFrame$relapse_fu_any_01[which(recordRemovedDataFrame$relapse_fu_any_01 > 0)] <- 1

# convert prebl_edssprog and prebl_edssconf3 to factors including one category for missing values

recordRemovedDataFrame <- convertPreblBinaries(recordRemovedDataFrame)

# coding factors
coded_dataframe <- euclideanFactorCoding(recordRemovedDataFrame, c("new_pat_id", "idx_dt"))

# The above is wrong for last_cranial_num and last_spinal_num
# 
# convert dates and years into discrete ordinals



# how about the missing values in last_cranial_num and last_spinal_num?



# after coding split into 4 cohorts

dataContinue <- coded_dataframe[which(coded_dataframe$tblcoh == 1),]
dataB2B <- coded_dataframe[which(coded_dataframe$tblcoh == 2),]
dataB2F <- coded_dataframe[which(coded_dataframe$tblcoh == 3),]
dataB2S <- coded_dataframe[which(coded_dataframe$tblcoh == 4),]


# impute the missing values in prebl_edss_score and years_diag_idx

source("functions/categoriseOrdinal.R")

dataContinue <- 
  cbind(dataContinue, 
        categoriseOrdinal(dataContinue$prebl_edss_score, 
                                    "prebl_edss_score",
                                    c(1, 1.5, 2.5), c("0", "1", "1.5-2", ">2")))
dataContinue$prebl_edss_score <-NULL

dataB2B <- 
  cbind(dataB2B, 
        categoriseOrdinal(dataB2B$prebl_edss_score, 
                                    "prebl_edss_score",
                                    c(1, 1.5, 2.5), c("0", "1", "1.5-2", ">2")))
dataB2B$prebl_edss_score <-NULL

dataB2F <- 
  cbind(dataB2F, 
        categoriseOrdinal(dataB2F$prebl_edss_score, 
                                    "prebl_edss_score",
                                    c(1, 1.5, 2.5), c("0", "1", "1.5-2", ">2")))
dataB2F$prebl_edss_score <-NULL

dataB2S <- 
  cbind(dataB2S, 
        categoriseOrdinal(dataB2S$prebl_edss_score, 
                                    "prebl_edss_score",
                                    c(1, 1.5, 2.5), c("0", "1", "1.5-2", ">2")))
dataB2S$prebl_edss_score <-NULL


dataContinue$years_diag_idx <- medianImputeOneVar(dataContinue$years_diag_idx)
dataB2B$years_diag_idx <- medianImputeOneVar(dataB2B$years_diag_idx)
dataB2F$years_diag_idx <- medianImputeOneVar(dataB2F$years_diag_idx)
dataB2S$years_diag_idx <- medianImputeOneVar(dataB2S$years_diag_idx)



# remove records of the same patients in each cohort with interval(s) shorter than 1 year

# cat("Removing duplicates for continue:\n")
# dataContinue <- removeRecordsShortInterval(dataContinue)
# cat("Removing duplicates for B2B:\n")
# dataB2B <- removeRecordsShortInterval(dataB2B)
# cat("Removing duplicates for B2F:\n")
# dataB2F <- removeRecordsShortInterval(dataB2F)
# cat("Removing duplicates for B2S:\n")
# dataB2S <- removeRecordsShortInterval(dataB2S)

cat("Keeping duplicates for continue:\n")
dataContinue <- keepOneRecordPerPatient(dataContinue)
cat("Keeping duplicates for B2B:\n")
dataB2B <- keepOneRecordPerPatient(dataB2B)
cat("Keeping duplicates for B2F:\n")
dataB2F <- keepOneRecordPerPatient(dataB2F)
cat("Keeping duplicates for B2S:\n")
dataB2S <- keepOneRecordPerPatient(dataB2S)

# randomly permute the records

dataContinue <- dataContinue[sample(nrow(dataContinue)),]
dataB2B <- dataB2B[sample(nrow(dataB2B)),]
dataB2F <- dataB2F[sample(nrow(dataB2F)),]
dataB2S <- dataB2S[sample(nrow(dataB2S)),]

# remove "new_pat_id" and "idx_dt"

vars2Drop2ndRound <- c("new_pat_id", "idx_dt")

dataContinue <- dataContinue[, !(names(dataContinue) %in% vars2Drop2ndRound)]
dataB2B <- dataB2B[, !(names(dataB2B) %in% vars2Drop2ndRound)]
dataB2F <- dataB2F[, !(names(dataB2F) %in% vars2Drop2ndRound)]
dataB2S <- dataB2S[, !(names(dataB2S) %in% vars2Drop2ndRound)]

# # remove the tblcoh after splitting
# 
# dataContinue$tblcoh <- NULL
# dataB2B$tblcoh <- NULL
# dataB2F$tblcoh <- NULL
# dataB2B$tblcoh <- NULL

# split into edssprog, edssconf3 and relapse_fu, and with each to 1 for init model, 2 for hidden evaluation

timeStamp <- as.character(Sys.time())
timeStamp <- gsub(":", ".", timeStamp)  # replace ":" by "."
resultDir <- paste("./Results/", timeStamp, "/", sep = '')
dir.create(resultDir, showWarnings = TRUE, recursive = TRUE, mode = "0777")

# splitSaveData2Outcomes(dataContinue, resultDir)
# splitSaveData2Outcomes(dataB2B, resultDir)
# splitSaveData2Outcomes(dataB2F, resultDir)
# splitSaveData2Outcomes(dataB2S, resultDir)

splitSaveData3Outcomes(dataContinue, resultDir)
splitSaveData3Outcomes(dataB2B, resultDir)
splitSaveData3Outcomes(dataB2F, resultDir)
splitSaveData3Outcomes(dataB2S, resultDir)



