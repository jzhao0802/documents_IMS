convertDate2Ordinal <- function(dateFactor)
{
  dateSeries <- as.Date(dateFactor, format="%Y/%m/%d")
  startDate <- min(dateSeries)
  
  days <- dateSeries - startDate
  
  return (as.numeric(days))
}

convertYear2Ordinal <- function(yearFactor)
{
  yearSeries <- as.numeric(yearFactor)
  startYear <- min(yearSeries)
  
  years <- yearSeries - startYear
  
  return (years)
}