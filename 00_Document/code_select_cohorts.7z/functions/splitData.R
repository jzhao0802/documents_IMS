library(caret)# for stratification


# given the dataset with one output, divide it into 3 sets: 
# 1 for initial modellinng, 2 others for hidden evaluation

splitSaveData3Sets <- function(dataset, cohort_name, resultDir)
{
  # move the output to the 1st 
  
  if (any(names(dataset) == "edssprog"))
  {
    outcome_name <- "edssprog"
  } else if (any(names(dataset) == "edssconf3"))
  {
    outcome_name <- "edssconf3"
  } else if (any(names(dataset) == "relapse_fu_any_01"))
  {
    outcome_name <- "relapse_fu_any_01"
  } else if (any(names(dataset) == "progrelapse"))
  {
    outcome_name <- "progrelapse"
  } else
  {
    outcome_name <- "confrelapse"
  }
  
  # output_idx <- grep(outcome_name, names(dataset))
  output_idx <- which(names(dataset) == outcome_name)
  
  dataset <- dataset[, c(output_idx, (1:ncol(dataset))[-output_idx])]
  
  nHids <- 2
  
  
  # stratification.
  # currently fix it to: init model: 80%, 1st hidden: 10%, 2nd hidden: 10%
  kFolds = 10
  
  # to prevent unstratified data subsets (due to the data size)
  # use a check
  bStratValid <- FALSE
  nPosTot <- sum(dataset[, 1] == 1)
  nNegTot <- sum(dataset[, 1] == 0)
  pAvPos <- nPosTot / (nPosTot + nNegTot)
  pAvNeg <- nNegTot / (nPosTot + nNegTot)
  pPosThreshL <- pAvPos * 0.8
  pNegThreshL <- pAvNeg * 0.8
  pPosThreshH <- pAvPos * 1.25
  pNegThreshH <- pAvNeg * 1.25
  nTrialsLimit <- 100
  iTrialsLimit <- 1
  while (bStratValid == FALSE)
  {
    folds <- createFolds(dataset[, 1], k=kFolds, returnTrain=TRUE)
    # check
    bLocalEvidence <- TRUE
    for (iHid in 1:nHids)
    {
      rest_ids <- folds[[iHid]]
      hid_ids <- (1:nrow(dataset))[-rest_ids]
      nPos <- sum(dataset[hid_ids, 1] == 1)
      nNeg <- sum(dataset[hid_ids, 1] == 0)
      pPos <- nPos / (nPos + nNeg)
      pNeg <- 1 - pPos
      
      bLocalEvidence <- bLocalEvidence & 
        ((pPos >= pPosThreshL) & (pNeg >= pNegThreshL) & (pPos <= pPosThreshH) & (pNeg <= pNegThreshH))
    }
    
    if (bLocalEvidence)
    {
      bStratValid <- TRUE
    }
    
    # 
    iTrialsLimit = iTrialsLimit + 1
    if (iTrialsLimit > nTrialsLimit)
    {
      break
    }
  }
  
  if (iTrialsLimit > nTrialsLimit)
  {
    cat(paste("Difficult to stratify: ", cohort_name, outcome_name, "pAvPos: ", pAvPos, "\n"))
  }
  
  
  
  # save datasets
  
  hid_ids_2sets <- vector()
  dataset_stats <- data.frame(matrix(ncol=4,nrow=3)) # for holding some stats of the datasets
  colnames(dataset_stats) <- c("nPos","nNeg","pPos","pNeg")
  rownames(dataset_stats) <- c("hid1", "hid2", "init_model")
  for (iHid in 1:nHids)
  {
    rest_ids <- folds[[iHid]]
    hid_ids <- (1:nrow(dataset))[-rest_ids]
    hid_ids_2sets <- c(hid_ids_2sets, hid_ids)
    
    write.table(dataset[hid_ids,], 
                file=paste(resultDir,"data_",cohort_name,"_",outcome_name,paste("hid",iHid,sep=""),".csv",sep=""), 
                sep=",", row.names=FALSE)
    
    # save stats
    nPos <- sum(dataset[hid_ids, 1] == 1)
    nNeg <- sum(dataset[hid_ids, 1] == 0)
    pPos <- round(nPos / (nPos + nNeg), 3)
    pNeg <- 1 - pPos
    dataset_stats[iHid, 1] <- nPos
    dataset_stats[iHid, 2] <- nNeg
    dataset_stats[iHid, 3] <- pPos
    dataset_stats[iHid, 4] <- pNeg
  }
  
  init_model_ids <- (1:nrow(dataset))[-hid_ids_2sets]
  write.table(dataset[init_model_ids,], 
              file=paste(resultDir,"data_",cohort_name,"_",outcome_name,"_initmodel.csv",sep=""), 
              sep=",", row.names=FALSE)
  
  nPos <- sum(dataset[init_model_ids, 1] == 1)
  nNeg <- sum(dataset[init_model_ids, 1] == 0)
  pPos <- round(nPos / (nPos + nNeg), 3)
  pNeg <- 1 - pPos
  dataset_stats[nrow(dataset_stats), 1] <- nPos
  dataset_stats[nrow(dataset_stats), 2] <- nNeg
  dataset_stats[nrow(dataset_stats), 3] <- pPos
  dataset_stats[nrow(dataset_stats), 4] <- pNeg
  
  write.table(dataset_stats, 
              file=paste(resultDir,"cls_percents_",cohort_name,"_",outcome_name,".csv",sep=""), 
              sep=",", col.names=NA)
  
}

nosplitSaveData <- function(dataset, cohort_name, resultDir)
{
  # move the output to the 1st 
  
  if (any(names(dataset) == "edssprog"))
  {
    outcome_name <- "edssprog"
  } else if (any(names(dataset) == "edssconf3"))
  {
    outcome_name <- "edssconf3"
  } else if (any(names(dataset) == "relapse_fu_any_01"))
  {
    outcome_name <- "relapse_fu_any_01"
  } else if (any(names(dataset) == "progrelapse"))
  {
    outcome_name <- "progrelapse"
  } else
  {
    outcome_name <- "confrelapse"
  }
  
  # output_idx <- grep(outcome_name, names(dataset))
  output_idx <- which(names(dataset) == outcome_name)
  
  dataset <- dataset[, c(output_idx, (1:ncol(dataset))[-output_idx])]
  
  # save datasets
  
  dataset_stats <- data.frame(matrix(ncol=4,nrow=1)) # for holding some stats of the datasets
  colnames(dataset_stats) <- c("nPos","nNeg","pPos","pNeg")
  # rownames(dataset_stats) <- c("hid1", "hid2", "init_model")
  
  write.table(dataset, 
              file=paste(resultDir,"data_",cohort_name,"_",outcome_name,".csv",sep=""), 
              sep=",", row.names=FALSE)
  
  nPos <- sum(dataset[, 1] == 1)
  nNeg <- sum(dataset[, 1] == 0)
  pPos <- nPos / (nPos + nNeg)
  pNeg <- 1 - pPos
  dataset_stats[1, 1] <- nPos
  dataset_stats[1, 2] <- nNeg
  dataset_stats[1, 3] <- pPos
  dataset_stats[1, 4] <- pNeg
  
  write.table(dataset_stats, 
              file=paste(resultDir,"cls_percents_",cohort_name,"_",outcome_name,".csv",sep=""), 
              sep=",", row.names=FALSE)
  
}


# split to two first: one for edssprog and the other for relapse_fu
# then within each,  split to three: 1 for initial modellinng, 2 others for hidden evaluation

splitSaveData2Outcomes <- function(dataset, resultDir)
{
  if (dataset$tblcoh[1] == 1)
  {
    data_name <- "continue"
    dataset$switch_rx_dayssup <- NULL # remove switch_rx_dayssup or precont_dayssup depending on the cohorts
  } else if (dataset$tblcoh[1] == 2)
  {
    data_name <- "B2B"
    dataset$precont_dayssup <- NULL
  } else if (dataset$tblcoh[1] == 3)
  {
    data_name <- "B2F"
    dataset$precont_dayssup <- NULL
  } else
  {
    data_name <- "B2S"
    dataset$precont_dayssup <- NULL
  }
  
  # remove tblcoh
  dataset$tblcoh <- NULL
  
  
  # separate the two outcomes
  data_edssprog <- dataset
  data_edssprog$relapse_fu_any_01 <- NULL
  
  data_relapse_fu <- dataset
  data_relapse_fu$edssprog <- NULL
  
  # for each outcome, divide to 3 sets
  
  splitSaveData3Sets(data_edssprog, data_name, resultDir)
  
  splitSaveData3Sets(data_relapse_fu, data_name, resultDir)
  
  tmp <- 1
  return (tmp)
  
}

# split the data to 5 outcomes: 3 individuals and 2 combined
# 1. edssprog
# 2. edssconf3
# 3. relapse_fu
# 4. edssprog + relapse_fu
# 5. edssconf3 + relapse_fu

splitSaveData3Outcomes <- function(dataset, resultDir)
{
  if (dataset$tblcoh[1] == 1)
  {
    data_name <- "continue"
    dataset$switch_rx_dayssup <- NULL # remove switch_rx_dayssup or precont_dayssup depending on the cohorts
  } else if (dataset$tblcoh[1] == 2)
  {
    data_name <- "B2B"
    dataset$precont_dayssup <- NULL
  } else if (dataset$tblcoh[1] == 3)
  {
    data_name <- "B2F"
    dataset$precont_dayssup <- NULL
  } else
  {
    data_name <- "B2S"
    dataset$precont_dayssup <- NULL
  }
  
  # remove tblcoh
  dataset$tblcoh <- NULL
  
  # separate the two outcomes
  data_edssprog <- dataset
  data_edssprog$edssconf3 <- NULL
  data_edssprog$relapse_fu_any_01 <- NULL
  
  data_edssconf3 <- dataset
  data_edssconf3$edssprog <- NULL
  data_edssconf3$relapse_fu_any_01 <- NULL
  
  data_relapse_fu <- dataset
  data_relapse_fu$edssprog <- NULL
  data_relapse_fu$edssconf3 <- NULL
  
  # the 1st combined outcome
  
  data_combined_progrelapse <- dataset
  
  data_combined_progrelapse$progrelapse <- 
    data_combined_progrelapse$edssprog | data_combined_progrelapse$relapse_fu_any_01
  data_combined_progrelapse$progrelapse <- 
    as.integer(data_combined_progrelapse$progrelapse)
  
  data_combined_progrelapse$edssprog <- NULL
  data_combined_progrelapse$edssconf3 <- NULL
  data_combined_progrelapse$relapse_fu_any_01 <- NULL
  
  # the 2nd combined outcome
  
  data_combined_confrelapse <- dataset
  data_combined_confrelapse$confrelapse <- 
    data_combined_confrelapse$relapse_fu_any_01 | data_combined_confrelapse$edssconf3
  data_combined_confrelapse$confrelapse <- 
    as.integer(data_combined_confrelapse$confrelapse)
  
  data_combined_confrelapse$edssprog <- NULL
  data_combined_confrelapse$edssconf3 <- NULL
  data_combined_confrelapse$relapse_fu_any_01 <- NULL
  
  
  # for each outcome, divide to 3 sets
  
  nosplitSaveData(data_edssprog, data_name, resultDir)
  nosplitSaveData(data_edssconf3, data_name, resultDir)
  nosplitSaveData(data_relapse_fu, data_name, resultDir)
  
  nosplitSaveData(data_combined_progrelapse, data_name, resultDir)
  nosplitSaveData(data_combined_confrelapse, data_name, resultDir)
  
}