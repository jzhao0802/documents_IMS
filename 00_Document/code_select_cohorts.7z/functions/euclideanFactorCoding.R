# euclidean factor coding converts NA in each category variable to 
# an additional binary variable. 
# so better convert any other representations of missing values to NA before 
# calling this funciton. 
# for NA in a continuous variable it's retained. 

library(stringr)

euclideanFactorCoding <- function(orgDataFrame, nochange_var_names)
{
  orgVarNames <- names(orgDataFrame)
  nData <- nrow(orgDataFrame)
  
  # count the number of columns needed
  
  count <- 0
  for (iVar in 1:ncol(orgDataFrame))
  {
    if (is.factor(orgDataFrame[,iVar]) & (!any(orgVarNames[iVar] == nochange_var_names)))
    {
      nLevels <- length(levels(orgDataFrame[,iVar]))
      if (nLevels > 2)
      {
        count = count + nLevels
        
        if (any(is.na(orgDataFrame[,iVar]))) {
          count = count + 1 # if it's a category variable and has missing values named 'NA'
        }
        
      }else   #binary
      {
        count = count + 1
        
        if (any(is.na(orgDataFrame[,iVar]))) {
          count = count + 2 # for binary, 1 col -> 3 cols
        }
      }
      
    }else # ordinal/continuous
    {
      count = count + 1
    }
  }
  
  # create a matrix for holding the results
  
  result_dataframe <- data.frame(matrix(0.0, ncol=count, nrow=nData))
  # resultNames <- character(count)
  
  # fill in the resultant matrix
  
  iColInResult <- 1
  for (iVar in 1:ncol(orgDataFrame))
  {
    if ((!is.factor(orgDataFrame[,iVar])) | any(orgVarNames[iVar] == nochange_var_names))
    {
      # just copy the vector
      result_dataframe[, iColInResult] <- orgDataFrame[, iVar]
      colnames(result_dataframe)[iColInResult] <- orgVarNames[iVar]
      iColInResult = iColInResult + 1
    }else
    {
      itsLevels = levels(orgDataFrame[,iVar])
      nLevels <- length(itsLevels)
      
      b_na <- any(is.na(orgDataFrame[,iVar]))
      
      if ((nLevels == 2) & (!b_na)) # only for this it's 1 column
      {
#         # copy the vector first to get the NA values
#         result_dataframe[which(is.na(orgDataFrame[,iVar])), iColInResult] <- NA
        
        # binary coding
        iLevel <- 2 #this needs to be coded as 1
        result_dataframe[which(orgDataFrame[,iVar] == itsLevels[iLevel]), iColInResult] <- 1
        
        colnames(result_dataframe)[iColInResult] <- orgVarNames[iVar]
        
        iColInResult = iColInResult + 1
      }else
      {
        if (b_na) {
          n_bins <- nLevels + 1
        } else {
          n_bins <- nLevels
        }
        
        
        matThisVar <- data.frame(mat.or.vec(nData, n_bins))
        colnames(matThisVar) <- rep("", n_bins)
        # matThisVar[which(is.na(orgDataFrame[,iVar])),] <- NA
        
        # the contrastmatrix
        
        matContr <- diag(n_bins)
        
        # 
        
        for (i_bin in 1:n_bins)
        {
          if ((b_na) & (i_bin == n_bins)) {
            colnames(matThisVar)[i_bin] <- 
              paste(orgVarNames[iVar], "__NA", sep="")
            ids <- which(is.na(orgDataFrame[,iVar]))
          } else {
            colnames(matThisVar)[i_bin] <- 
              paste(orgVarNames[iVar], "__", 
                    str_replace_all(itsLevels[i_bin], " ", "_"), sep="")
            ids <- which(orgDataFrame[,iVar] == itsLevels[i_bin])
          }
          
          matThisVar[ids,] <- t(replicate(length(ids),matContr[i_bin,]))
        } 
        result_dataframe[,iColInResult:(iColInResult+n_bins-1)] <- matThisVar
        
        colnames(result_dataframe)[iColInResult:(iColInResult+n_bins-1)] <- 
          colnames(matThisVar)
        
        iColInResult = iColInResult + n_bins
      }
      
    }
  }
  
  return (result_dataframe)
}

# the input to the following function is only supposed to be factors

euclideanFactorCoding_GivenCols2Encode <- function(org_data, colnames_2_encode)
{
  orgVarNames <- names(org_data)
  nData <- nrow(org_data)
  
  # count the number of columns needed
  
  count <- 0
  for (iVar in 1:ncol(org_data))
  {
    if (any(orgVarNames[iVar] == colnames_2_encode)) {
      count = count + length(levels(factor(org_data[, iVar])))
      if (any(is.na(org_data[, iVar]))) {
        count = count + 1 # one more column for NA
      }
    } else {
      count = count + 1
    }
  }
  
  # create a matrix for holding the results
  
  result_dataframe <- data.frame(matrix(0.0, ncol=count, nrow=nData))
  # resultNames <- character(count)
  
  # fill in the resultant matrix
  
  iColInResult <- 1
  for (iVar in 1:ncol(org_data))
  {
    if (!any(orgVarNames[iVar] == colnames_2_encode)) {
      result_dataframe[, iColInResult] <- org_data[, iVar]
      colnames(result_dataframe)[iColInResult] <- orgVarNames[iVar]
      iColInResult = iColInResult + 1
    } else {
      b_na <- any(is.na(orgDataFrame[,iVar]))
      
      if ((nLevels == 2) & (!b_na)) # only for this it's 1 column
      {
        # binary coding
        iLevel <- 2 #this needs to be coded as 1
        result_dataframe[which(orgDataFrame[,iVar] == itsLevels[iLevel]), iColInResult] <- 1
        
        colnames(result_dataframe)[iColInResult] <- orgVarNames[iVar]
        
        iColInResult = iColInResult + 1
      }else
      {
        if (b_na) {
          n_bins <- nLevels + 1
        } else {
          n_bins <- nLevels
        }
        
        matThisVar <- data.frame(mat.or.vec(nData, n_bins))
        colnames(matThisVar) <- rep("", n_bins)
        # matThisVar[which(is.na(orgDataFrame[,iVar])),] <- NA
        
        # the contrastmatrix
        
        matContr <- diag(n_bins)
        
        # 
        
        for (i_bin in 1:n_bins)
        {
          if ((b_na) & (i_bin == n_bins)) {
            colnames(matThisVar)[i_bin] <- 
              paste(orgVarNames[iVar], "__NA", sep="")
            ids <- which(is.na(orgDataFrame[,iVar]))
          } else {
            colnames(matThisVar)[i_bin] <- 
              paste(orgVarNames[iVar], "__", 
                    str_replace_all(itsLevels[i_bin], " ", "_"), sep="")
            ids <- which(orgDataFrame[,iVar] == itsLevels[i_bin])
          }
          
          matThisVar[ids,] <- t(replicate(length(ids),matContr[i_bin,]))
        } 
        result_dataframe[,iColInResult:(iColInResult+n_bins-1)] <- matThisVar
        
        colnames(result_dataframe)[iColInResult:(iColInResult+n_bins-1)] <- 
          colnames(matThisVar)
        
        iColInResult = iColInResult + n_bins
      }
    }
  }
  
  return (result_dataframe)
}