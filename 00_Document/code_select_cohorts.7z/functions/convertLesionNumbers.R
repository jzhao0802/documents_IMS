
# Output: a vector of factor levels (i.e., 0, 1, 2, 3,) without using binary coding. 
# Before fed into modelling, extra coding is needed. 

convertSpinalNumbers <- function(org_num)
{
  # both blank and unknown are treated as one level
  # for the numbers, select a threshold, below the threshold will be 0 and above 1
  # so 3 levels: 0, 1, 2
  
  result_num <- rep("<=2", length(org_num))
  result_num[which(org_num == ">2")] <- ">2"
  result_num[which((org_num == "") | (org_num == "unknown"))] <- "NA"
  
  result_num <- factor(result_num)
  
  return (result_num)
}

convertCranialNumbers <- function(org_num)
{
  # blank, unknown and ambiguous are all treated as one level
  # for the numbers, select a threshold, below the threshold will be 0 and above 1
  # so 3 levels: 0, 1, 2
  
  result_num <- rep("<=8", length(org_num))
  result_num[which(org_num == ">8")] <- ">8"
  result_num[which((org_num == "") | (org_num == "unknown") | (org_num == "ambiguous"))] <- "NA"
  
  result_num <- factor(result_num)
  
  
  
  return (result_num)
}