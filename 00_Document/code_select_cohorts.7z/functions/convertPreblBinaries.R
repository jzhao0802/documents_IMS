convertPreblBinaries <- function(dataset)
{
  dataset$prebl_edssprog[which(is.na(dataset$prebl_edssprog))] <- "NA"
  dataset$prebl_edssprog <- factor(dataset$prebl_edssprog)
  
  dataset$prebl_edssconf3[which(is.na(dataset$prebl_edssconf3))] <- "NA"
  dataset$prebl_edssconf3 <- factor(dataset$prebl_edssconf3)
  
  return (dataset)
}