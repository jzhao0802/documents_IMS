# this function convertDate2DrugAvailability is very specific to the dataset

convertDate2DrugAvailability <- function(orgDataFrame)
{
  fingolimod <- min(as.Date(orgDataFrame$idx_dt[which(orgDataFrame$idx_rx == 1)], 
                            format="%Y/%m/%d"))
  
  natalizumab <- min(as.Date(orgDataFrame$idx_dt[which(orgDataFrame$idx_rx == 3)], 
                             format="%Y/%m/%d"))
  
  tecfidera <- min(as.Date(orgDataFrame$idx_dt[which(orgDataFrame$idx_rx == 10)], 
                           format="%Y/%m/%d"))
  
  aubagio <- min(as.Date(orgDataFrame$idx_dt[which(orgDataFrame$idx_rx == 11)], 
                         format="%Y/%m/%d"))
  
  dateSeries <- as.Date(orgDataFrame$idx_dt, format="%Y/%m/%d")
  
  # 
#   Natalizumab: 2010-01-01
#   Fingolimod: 2011-03-17
#   Aubagio: 2013-10-01
#   Tecfidera: 2014-01-31
  
  
  # natalizumab exists since the start of the study. Don't use it. 
  # for the other 3: 
  
  nData <- nrow(orgDataFrame)
  fingolimodVec <- mat.or.vec(nData,1)
  aubagioVec <- mat.or.vec(nData,1)
  tecfideraVec <- mat.or.vec(nData,1)
  
  fingolimodVec[which(dateSeries >= fingolimod)] <- 1
  aubagioVec[which(dateSeries >= aubagio)] <- 1
  tecfideraVec[which(dateSeries >= tecfidera)] <- 1
  
  # put into the result data.frame
  
  result.data.frame <- orgDataFrame
  
  result.data.frame$fingolimod <- fingolimodVec
  result.data.frame$aubagio <- aubagioVec
  result.data.frame$tecfidera <- tecfideraVec
  
  # keep it for checking the intervals later
  # result.data.frame$idx_dt <- NULL
  
  return (result.data.frame)
  
  
}