medianImputeOneVar <- function(dataVec)
{
  dataVec = as.numeric(dataVec)
  m <- median(dataVec, na.rm=TRUE)
  dataVec[which(is.na(dataVec))] <- m
  
  return (dataVec)
}