

# remove records of the same patients in each cohort with interval(s) shorter than 1 year
# a by product of this function is that the order of the records are changed 
# (duplicated but retained records are at the end of the dataset)

removeRecordsShortInterval <- function(dataset)
{
  # extract indices of all duplicates
  
  dup_indices <- which(duplicated(dataset$new_pat_id) | duplicated(dataset$new_pat_id, fromLast=TRUE))
  
  dup_data <- dataset[dup_indices, ]
  nondup_data <- dataset[-dup_indices,]
  
  # sort the duplicates by new_pat_id to make sure the same ids are together
  
  dup_data <- dup_data[order(dup_data$new_pat_id),]
  
  # the intervals (if different patients, put it as very long)
  
  intervals <- rep(0.0, length(dup_indices))
  intervals[2:length(intervals)] <- 
    as.Date(dup_data$idx_dt[2:length(intervals)]) - 
    as.Date(dup_data$idx_dt[1:(length(intervals)-1)])
  
  bIsDiffID <- rep(TRUE, length(dup_indices))
  bIsDiffID[2:length(bIsDiffID)] <- 
    (dup_data$new_pat_id[2:length(bIsDiffID)] != 
       dup_data$new_pat_id[1:(length(bIsDiffID)-1)])
  
  intervals[bIsDiffID] <- 1e4
    
  
  # for each patient, keep the earliest record, then keep removing from the second
  # earliest until the interval is larger than 1 year
  
  thresh <- 365
  
  indices2Remove <- (abs(intervals) <= thresh)
  
  cat(paste("No. of removed: ", sum(indices2Remove), "\n", sep=""))
  
  dup_data <- dup_data[!indices2Remove, ]
  
  # combine with the non-duplicating records to form the output
  
  result_data <- rbind(nondup_data, dup_data)
  
  return (result_data)
}

keepOneRecordPerPatient <- function(dataset)
{
  # extract indices of all duplicates
  
  dup_indices <- which(duplicated(dataset$new_pat_id) | duplicated(dataset$new_pat_id, fromLast=TRUE))
  
  dup_data <- dataset[dup_indices, ]
  nondup_data <- dataset[-dup_indices,]
  
  pat_ids <- as.integer(levels(factor(dup_data$new_pat_id)))
  
  kept_dupdata <- dup_data[1:length(pat_ids),]
  
  for (iPatID in 1:length(pat_ids))
  {
    entries <- dup_data[which(dup_data$new_pat_id == pat_ids[iPatID]),]
    select <- sample(nrow(entries))[1]
    kept_dupdata[iPatID,] <- entries[select,]
  }
  
  cat(paste("No. of removed: ", nrow(dup_data) - nrow(kept_dupdata), "\n", sep=""))
  
  # combine with the non-duplicating records to form the output
  
  result_data <- rbind(nondup_data, kept_dupdata)
  
  return (result_data)
}