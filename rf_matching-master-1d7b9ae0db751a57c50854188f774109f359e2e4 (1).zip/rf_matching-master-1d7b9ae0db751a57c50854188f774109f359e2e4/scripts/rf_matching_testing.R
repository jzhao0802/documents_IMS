# ------------------------------------------------------------------------------
#
#                   PERFORMANCE TESTING: LR, ELASTIC NET, RF
#
# ------------------------------------------------------------------------------

library(mlr)
library(readr)
library(parallel)
library(parallelMap)
source("palab_model/palab_model.R")
setwd("F:/Daniel/rf_matching_testing/")

run_nested_model <- function(model){
  # ----------------------------------------------------------------------------
  # ELASTIC NET
  # ----------------------------------------------------------------------------
  if (model=="elasticnet"){
    lrn <- makeLearner("classif.glmnet", predict.type="prob")

    # Define grid
    ps <- makeParamSet(
      makeDiscreteParam("alpha", values=c(0, .5, 1)),
      makeDiscreteParam("s", values=c(0.001, 0.005, 0.01, 0.05))
    )
    
    # Define grid search
    ctrl <- makeTuneControlGrid()
    
  # ----------------------------------------------------------------------------
  # RF
  # ----------------------------------------------------------------------------
  } else if(model=="rf"){
    lrn <- makeLearner("classif.ranger", predict.type="prob")

    # Cheaper than OOB/permutation estimation of feature importance
    lrn <- setHyperPars(lrn, importance="impurity")

    # Minimum node size depends on the number of positives
    pos_N <- sum(as.numeric(getTaskTargets(dataset))-1)
    min_node_sizes <- as.integer(pos_N * c(.1, .2, .3))

    # Define grid
    ps <- makeParamSet(
      makeDiscreteParam("num.trees", values=c(100, 300, 500)),
      makeDiscreteParam("min.node.size", values=min_node_sizes),
      makeLogicalParam("replace"),
      makeDiscreteParam("sample.fraction", values=c(1))
    )
    
    # Define grid search
    ctrl <- makeTuneControlGrid()
    
  # ----------------------------------------------------------------------------
  # SVM
  # ----------------------------------------------------------------------------
  } else if(model=="svm"){
    
    # Define SVM with RBF kernel. 
    lrn <- makeLearner("classif.ksvm", predict.type="prob",
                       par.vals = list(kernel = "rbfdot"))
    
    # Define hyper parameters
    ps <- makeParamSet(
      makeNumericParam("C", lower = -5, upper = 5, trafo = function(x) 2^x),
      makeNumericParam("sigma", lower = -5, upper = 5, trafo = function(x) 2^x)
    )
    
    # Define random grid search with 12 points
    ctrl <- makeTuneControlRandom(maxit=12)
    
  # ----------------------------------------------------------------------------
  # XGBOOST
  # ----------------------------------------------------------------------------
  } else if(model=="xgboost"){ # XGBOOST
    # Make sure we sample according to inverse class frequency 
    pos_class_w <- get_class_freqs(dataset)
    iw <- unlist(lapply(getTaskTargets(dataset), function(x) 1/pos_class_w[x]))
    dataset$weights <- as.numeric(iw)
    
    # Define XGboost learner
    lrn <- makeLearner("classif.xgboost", predict.type="prob", 
                       predict.threshold=0.5)
    lrn$par.vals = list(
      nrounds = 100,
      verbose = F,
      objective = "binary:logistic"
      # for multiclass use objective = "multi:softmax"
    )
    
    # Define hyper parameters
    ps = makeParamSet(
      makeNumericParam("eta", lower=0.01, upper=0.3),
      makeIntegerParam("max_depth", lower=2, upper=6),
      makeIntegerParam("min_child_weight", lower=1, upper=5),
      makeNumericParam("colsample_bytree", lower=.5, upper=1),
      makeNumericParam("subsample", lower=.5, upper=1)
    )
    
    # Define random grid search with 12 points
    ctrl <- makeTuneControlRandom(maxit=12)
  }
  
  # ----------------------------------------------------------------------------
  # Rest of the model spec is the same for all learners
  # ----------------------------------------------------------------------------
  
  # Define performane metrics
  pr10 <- make_custom_pr_measure(10, "pr10")
  pr15 <- make_custom_pr_measure(15, "pr15")
  pr20 <- make_custom_pr_measure(20, "pr20")
  m_all <- list(pr10, pr15, pr20, auc)
  
  # Define outer and inner resampling strategies
  outer <- makeResampleDesc("CV", iters=3, predict = "both")
  
  # The inner could be "Subsample" if we don't have enough positive samples
  inner <- makeResampleDesc("CV", iters=3)
  
  lrn_wrap <- makeTuneWrapper(lrn, resampling=inner, par.set=ps, control=ctrl,
                              show.info=F, measures=m_all)
  
  # Run nested CV
  parallelStartSocket(num_cores, level="mlr.tuneParams")
  res <- resample(lrn_wrap, dataset, resampling=outer, models=T,
                  extract=getTuneResult, show.info=F, measures=m_all)  
  parallelStop()

  # Save results
  extra <- list("Bootstrap"="True",
                "NumFeatures"=sum(dataset$task.desc$n.feat),
                "NumSamples"=dataset$task.desc$size,
                "ElapsedTime(mins)"=res$runtime,
                "RandomSeed"=random_seed,
                "Recall"=10)

  # Save all these results into a csv
  get_results(res, grid_ps=ps, extra=extra, detailed=T, all_measures=T,
              write_csv=T, output_folder="results/")
  res
}

# ------------------------------------------------------------------------------
# Define main varaibles, load data
# ------------------------------------------------------------------------------

random_seed <- 123
set.seed(random_seed, "L'Ecuyer")
recall_thrs <- 5

# Use half of the server's capacity, memory is already set to max by default
num_cores <- 20

# load data and var_config
df = readr::read_csv("data/data.csv")
var_config <- readr::read_csv("data/var_config.csv")

# define dataset
match <- df$matched_id
ids <- get_ids(df, var_config)
df <- get_variables(df, var_config, categorical = T)
dataset <- makeClassifTask(id="abv", data=df, target="label", positive=1)
# dataset$blocking <- as.factor(match)

# run model
res <- run_nested_model("rf")

