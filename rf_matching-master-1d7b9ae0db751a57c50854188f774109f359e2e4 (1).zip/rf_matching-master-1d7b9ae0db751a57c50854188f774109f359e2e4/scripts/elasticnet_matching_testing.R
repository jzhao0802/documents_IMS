library(mlr)
library(readr)
library(parallel)
library(parallelMap)
source("palab_model/palab_model.R")
setwd("F:/Daniel/rf_matching_testing/")

# ------------------------------------------------------------------------------
# Define main varaibles, load data
# ------------------------------------------------------------------------------

df = readr::read_csv("data/data.csv")
random_seed <- 123
set.seed(random_seed, "L'Ecuyer")
n_exp = 20

# load data and var_config
df = readr::read_csv("data/data.csv")
var_config <- readr::read_csv("data/var_config.csv")

# define matching and non-matching dataset
match <- df$matched_id
ids <- get_ids(df, var_config)
df <- get_variables(df, var_config, categorical = T)
dataset <- makeClassifTask(id="abv", data=df, target="label", positive=1)
dataset_m <- dataset
dataset_m$blocking <- as.factor(match)

# ------------------------------------------------------------------------------
# Define model params
# ------------------------------------------------------------------------------

# Define logistic regression with elasticnet penalty
lrn <- makeLearner("classif.logreg", predict.type="prob", predict.threshold=0.5)

# Define outer resampling strategies: if matched, use ncv
outer <- makeResampleDesc("CV", iters=3, stratify=T)
outer_m <- makeResampleDesc("CV", iters=3)

# Define performane metrics
pr10 <- make_custom_pr_measure(10, "pr10")
pr15 <- make_custom_pr_measure(15, "pr15")
pr20 <- make_custom_pr_measure(20, "pr20")
m_all <- list(pr10, pr15, pr20, auc)

# results variables
results <- c()
results_m <- c()

# ------------------------------------------------------------------------------
# Fit LR on subsampled data n_exp times, then save results
# ------------------------------------------------------------------------------

for (i in 1:n_exp){
  # fit non-matched model
  data <- downsample(dataset, .05)
  parallelStartSocket(3, level="mlr.resample")
  res <- resample(lrn, data, resampling=outer, measures=m_all)
  parallelStop()
  results <- rbind(results, unlist(lapply(res$measures.test, mean)[2:5]))
  
  # fit matched data
  data_m <- downsample(dataset_m, .05)
  parallelStartSocket(3, level="mlr.resample")
  res_m <- resample(lrn, data_m, resampling=outer_m, measures=m_all)
  parallelStop()
  results_m <- rbind(results_m, unlist(lapply(res_m$measures.test, mean)[2:5]))
}

rownames(results) <- NULL
rownames(results_m) <- NULL
write_csv(data.frame(cbind(results, results_m)), "results/LR_bootstrap.csv")