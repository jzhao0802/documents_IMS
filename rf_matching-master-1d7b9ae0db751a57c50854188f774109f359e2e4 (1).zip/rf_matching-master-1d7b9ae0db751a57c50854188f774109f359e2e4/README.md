# RF with and without matching

## Experiment A
1.	I took the smallest abbvie data from Orla ( which has 1 to 10 pos neg ratio if I�m not mistaken)
2.	This dataset has a matching column.
3.	I set up a 3 fold nested CV model with the following grid:
a.	Number of trees: 100, 300, 500
b.	Minimum node size: 10%, 20%, 30% of the number of positives
c.	Sample with replacement: TRUE or FALSE
d.	Sampling ratio fixed at 1.
4.	I�m measuring the performance of each grid point by calculating  PR10, PR15, PR20, and AUC. 

This way we�re accessing if how the model performs with bootstrap (sample with replacement = TRUE) and without bootstrap (sample with replacement = FALSE) given we have matched data and we vary the usual hyper parameters. 

## Experiment B
As a follow up and control experiment (let�s call it experiment B) I�m planning to do the exact same thing, with the exact same data, but without matching. I.e. with the usual CV. I didn�t think of this yesterday but this is crucial in interpreting the results of the experiment A. 

## LR experiment
1.	Extract two types of datasets from the existing abbvie (or whatever, but must be from the same source). 
2.	The difference between the two datasets are: one has the matching and the other doesn't. 
3.	The two datasets have the same number of positives and the same number of negatives. 
4.	Perform cross evaluation on each dataset (it's standard LR so there's no hyper params). This gives two sets of results, each set corresponding to one dataset. 
5.	Repeat 1 - 4 10 times (by changing the seed for extracting the datasets) to get 20 sets of results, 10 with matching and 10 without. 
6.	Observe whether there's any significant difference between the choices of with / without matching
